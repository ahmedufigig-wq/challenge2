plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// مفتاح توقيع ثابت: يجعل كل نسخة جديدة تُثبَّت فوق القديمة كتحديث (بدل أن تُرفض)
val keystoreFile = rootProject.file("challenge.jks")

android {
    namespace = "com.friends.quiz"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.friends.challenge"
        // 21 = Android 5.0 وما فوق (يغطي تقريباً كل الهواتف المستخدمة)
        minSdk = 21
        targetSdk = 34
        // عند كل تحديث جديد زد رقم versionCode بمقدار 1
        versionCode = 2
        versionName = "3.0"
    }

    signingConfigs {
        create("challenge") {
            storeFile = keystoreFile
            storePassword = "challenge123"
            keyAlias = "challenge"
            keyPassword = "challenge123"
        }
    }

    buildTypes {
        getByName("debug") {
            if (keystoreFile.exists()) {
                signingConfig = signingConfigs.getByName("challenge")
            }
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

// لا توجد أي مكتبات خارجية عمداً: التطبيق يعتمد على أندرويد الأساسي فقط
// حتى يعمل على كل الإصدارات ويبقى حجمه صغيراً.
