package com.friends.quiz

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.Drawable
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/*
 * الأشكال: سكنات الأسماء (تُشترى بالجواهر) + خلفيات الشاشات.
 * - لإضافة سكن جديد: أضف سطراً في SKINS (الاسم، السعر، الأيقونة، لون الخط، لونا الخلفية، لون الإطار).
 *   لا تغيّر ترتيب السطور الموجودة لأن رقم السكن محفوظ بحسب ترتيبه.
 * - لإضافة خلفية جديدة: أضف سطراً في THEMES (الاسم، اللون العلوي، اللون السفلي، النقش، لون النقش).
 */

private fun col(s: String): Int = Color.parseColor(s)

class Skin(
    val name: String,
    val price: Int,
    val icon: String,
    val textColor: Int,
    val c1: Int,
    val c2: Int,
    val border: Int
)

val SKINS: Array<Skin> = arrayOf(
    Skin("عادي", 0, "👤", Color.WHITE, col("#1F2447"), col("#2C3363"), col("#4A5399")),
    Skin("البرق", 100, "⚡", col("#FFF59D"), col("#2B2A00"), col("#6B5E00"), col("#FFD600")),
    Skin("الجليد", 150, "❄️", col("#E1F5FE"), col("#0D3B66"), col("#1B7BA8"), col("#81D4FA")),
    Skin("النار", 200, "🔥", col("#FFF3E0"), col("#7A1F00"), col("#E64A19"), col("#FFB300")),
    Skin("الغابة", 200, "🌿", col("#E8FFE8"), col("#0B3D2E"), col("#27AE60"), col("#7CFFB2")),
    Skin("الشبح", 300, "👻", Color.WHITE, col("#050505"), col("#7B0D1E"), col("#E53935")),
    Skin("الملكي", 400, "👑", col("#3B2A00"), col("#FFE082"), col("#FFB300"), col("#FFF8E1")),
    Skin("الألماس", 500, "💎", Color.WHITE, col("#4A00E0"), col("#00B4DB"), col("#B9F6FF")),
    Skin("قوس قزح", 600, "🌈", Color.WHITE, col("#FF416C"), col("#4776E6"), Color.WHITE),
    Skin("البطل", 800, "🏆", col("#FFD700"), col("#0F2027"), col("#2C5364"), col("#FFD700")),
    Skin("الأسطورة", 1200, "🐉", col("#FFD54F"), col("#1A0033"), col("#B00020"), col("#FFD54F"))
)

// ------------------------------------------------------------------ الخلفيات

const val P_NONE = 0
const val P_BUBBLES = 1
const val P_STARS = 2
const val P_STRIPES = 3
const val P_BURST = 4
const val P_GRID = 5
const val P_DIAMONDS = 6
const val P_WAVES = 7
const val P_SPLIT = 8
const val P_RINGS = 9
const val P_EMBERS = 10

class Theme(val name: String, val c1: Int, val c2: Int, val pattern: Int, val accent: Int)

val THEMES: Array<Theme> = arrayOf(
    Theme("ليل بنفسجي", col("#14172B"), col("#2D1B69"), P_STARS, Color.WHITE),
    Theme("أزرق محيطي", col("#0F2027"), col("#2C5364"), P_BUBBLES, Color.WHITE),
    Theme("غابة", col("#0B3D2E"), col("#1E8449"), P_STRIPES, Color.WHITE),
    Theme("غروب وردي", col("#3A0CA3"), col("#B5179E"), P_RINGS, Color.WHITE),
    Theme("حلبة التحدي", col("#7B1E1E"), col("#3B0A0A"), P_SPLIT, col("#1E5BFF")),
    Theme("فحمي", col("#111111"), col("#2B2B2B"), P_GRID, Color.WHITE),
    Theme("ذهب الملوك", col("#2B1D00"), col("#6B4A00"), P_DIAMONDS, col("#FFD54F")),
    Theme("فضاء عميق", col("#02030A"), col("#0B1A4A"), P_STARS, Color.WHITE),
    Theme("كثبان", col("#4A2C0A"), col("#C27C2C"), P_WAVES, col("#FFE0B2")),
    Theme("نيون", col("#0A0A1F"), col("#25004D"), P_STRIPES, col("#00E5FF")),
    Theme("بركان", col("#1A0500"), col("#8E1B00"), P_EMBERS, col("#FFB300")),
    Theme("أشعة البطولة", col("#0D1B4A"), col("#2A1566"), P_BURST, col("#FFD54F")),
    Theme("جليدي", col("#06293D"), col("#0E6F8F"), P_DIAMONDS, col("#B9F6FF")),
    Theme("الملعب", col("#0B3D1E"), col("#145A32"), P_RINGS, Color.WHITE),
    Theme("بنفسجي × برتقالي", col("#2A0A3D"), col("#12001F"), P_SPLIT, col("#FF6D00"))
)

const val DEFAULT_HOME_BG = 11
const val DEFAULT_ROOM_BG = 4

/** خلفية مرسومة بالكود: تدرّج لوني + نقش. لا تحتاج أي صور. */
class ThemeDrawable(private val t: Theme, private val density: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var shader: LinearGradient? = null
    private var lastW = 0f
    private var lastH = 0f
    private val n = 60
    private val px = FloatArray(n)
    private val py = FloatArray(n)
    private val pr = FloatArray(n)

    init {
        val r = Random(t.name.hashCode().toLong())
        for (i in 0 until n) {
            px[i] = r.nextFloat()
            py[i] = r.nextFloat()
            pr[i] = r.nextFloat()
        }
    }

    private fun accent(alpha: Int) {
        paint.color = t.accent
        paint.alpha = alpha
    }

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (w <= 0f || h <= 0f) return
        if (shader == null || w != lastW || h != lastH) {
            shader = LinearGradient(0f, 0f, 0f, h, t.c1, t.c2, Shader.TileMode.CLAMP)
            lastW = w
            lastH = h
        }
        val d = density
        paint.style = Paint.Style.FILL
        paint.shader = shader
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        when (t.pattern) {
            P_BUBBLES -> {
                for (i in 0 until 16) {
                    val r = (14f + pr[i] * 60f) * d
                    if (i % 2 == 0) {
                        paint.style = Paint.Style.FILL
                        accent(22)
                    } else {
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 2f * d
                        accent(45)
                    }
                    canvas.drawCircle(px[i] * w, py[i] * h, r, paint)
                }
            }
            P_STARS -> {
                paint.style = Paint.Style.FILL
                for (i in 0 until n) {
                    accent(50 + (pr[i] * 170f).toInt())
                    canvas.drawCircle(px[i] * w, py[i] * h, (1f + pr[i] * 2.2f) * d, paint)
                }
            }
            P_STRIPES -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 10f * d
                accent(20)
                val step = 46f * d
                var x = 0f
                while (x < w + h) {
                    canvas.drawLine(x, 0f, x - h, h, paint)
                    x += step
                }
            }
            P_BURST -> {
                paint.style = Paint.Style.FILL
                accent(34)
                val cx = w / 2f
                val cy = h * 0.36f
                val far = max(w, h) * 1.6f
                val rays = 24
                val step = 2.0 * Math.PI / rays
                for (i in 0 until rays step 2) {
                    val a1 = i * step
                    val a2 = a1 + step
                    path.reset()
                    path.moveTo(cx, cy)
                    path.lineTo(cx + (far * cos(a1)).toFloat(), cy + (far * sin(a1)).toFloat())
                    path.lineTo(cx + (far * cos(a2)).toFloat(), cy + (far * sin(a2)).toFloat())
                    path.close()
                    canvas.drawPath(path, paint)
                }
            }
            P_GRID -> {
                paint.style = Paint.Style.FILL
                accent(45)
                val step = 30f * d
                var y = step / 2f
                while (y < h) {
                    var x = step / 2f
                    while (x < w) {
                        canvas.drawCircle(x, y, 2f * d, paint)
                        x += step
                    }
                    y += step
                }
            }
            P_DIAMONDS -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1.5f * d
                accent(55)
                val step = 56f * d
                val half = 20f * d
                var row = 0
                var y = step / 2f
                while (y < h + step) {
                    var x = if (row % 2 == 0) step / 2f else step
                    while (x < w + step) {
                        path.reset()
                        path.moveTo(x, y - half)
                        path.lineTo(x + half, y)
                        path.lineTo(x, y + half)
                        path.lineTo(x - half, y)
                        path.close()
                        canvas.drawPath(path, paint)
                        x += step
                    }
                    y += step / 2f
                    row++
                }
            }
            P_WAVES -> {
                paint.style = Paint.Style.FILL
                for (k in 0 until 4) {
                    accent(18 + k * 9)
                    val base = h * (0.55f + 0.11f * k)
                    val amp = (36f - k * 4f) * d * (if (k % 2 == 0) 1f else -1f)
                    path.reset()
                    path.moveTo(0f, base)
                    path.quadTo(w * 0.25f, base - amp, w * 0.5f, base)
                    path.quadTo(w * 0.75f, base + amp, w, base)
                    path.lineTo(w, h)
                    path.lineTo(0f, h)
                    path.close()
                    canvas.drawPath(path, paint)
                }
            }
            P_SPLIT -> {
                // المنافسة: نصفان بلونين (أحمر ضد أزرق مثلاً) مع خط فاصل وبرق في المنتصف
                paint.style = Paint.Style.FILL
                accent(170)
                path.reset()
                path.moveTo(0f, h * 0.66f)
                path.lineTo(w, h * 0.22f)
                path.lineTo(w, h)
                path.lineTo(0f, h)
                path.close()
                canvas.drawPath(path, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f * d
                paint.color = Color.WHITE
                paint.alpha = 110
                canvas.drawLine(0f, h * 0.66f, w, h * 0.22f, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                paint.alpha = 38
                path.reset()
                path.moveTo(w * 0.56f, h * 0.36f)
                path.lineTo(w * 0.38f, h * 0.53f)
                path.lineTo(w * 0.49f, h * 0.53f)
                path.lineTo(w * 0.42f, h * 0.70f)
                path.lineTo(w * 0.64f, h * 0.47f)
                path.lineTo(w * 0.52f, h * 0.47f)
                path.close()
                canvas.drawPath(path, paint)
            }
            P_RINGS -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f * d
                accent(34)
                val cx = w / 2f
                val cy = h * 0.32f
                var r = 60f * d
                val limit = max(w, h) * 1.3f
                while (r < limit) {
                    canvas.drawCircle(cx, cy, r, paint)
                    r += 70f * d
                }
            }
            P_EMBERS -> {
                paint.style = Paint.Style.FILL
                for (i in 0 until n) {
                    val up = py[i] * py[i]
                    accent(60 + (pr[i] * 150f).toInt())
                    canvas.drawCircle(px[i] * w, h * (1f - up), (1.5f + pr[i] * 3f) * d, paint)
                }
            }
        }
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
